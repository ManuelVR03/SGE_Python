def main():
    base = int(input("Introduce la base: "))
    exp = int(input("Introduce el exponente: "))
    print("El resultado es: ", base**exp)

if __name__ == "__main__":
    main()